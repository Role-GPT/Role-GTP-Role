// BasicSettingsModal.tsx - 삭제됨
// UserAccountModal.tsx로 통합되었습니다.
// 이 파일은 더 이상 사용되지 않습니다.

// 통합된 기능:
// - 기본 설정과 고급 설정을 하나의 사용자 계정 모달로 통합
// - 탭 구조로 일반/외관/알림 설정 제공
// - 컨텍스트 전환이 자연스러운 UI/UX

console.warn('BasicSettingsModal.tsx는 더 이상 사용되지 않습니다. UserAccountModal.tsx를 사용하세요.');

export function BasicSettingsModal() {
  return null;
}

export default BasicSettingsModal;
