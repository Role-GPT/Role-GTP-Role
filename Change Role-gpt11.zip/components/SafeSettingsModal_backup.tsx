// SafeSettingsModal.tsx 백업 파일
// 빌드 에러 수정을 위해 백업됨
// 원본 파일은 재작성됨
