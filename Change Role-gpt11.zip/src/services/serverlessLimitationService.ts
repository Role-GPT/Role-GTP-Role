/**
 * 🔐 서버리스 모드별 제한사항 서비스
 * 
 * 모든 제한사항을 서버에서 관리하여 보안을 강화합니다.
 * 클라이언트에서는 단순히 서버 API를 호출하여 제한사항을 확인합니다.
 */

import { projectId, publicAnonKey } from '../../utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-e3d1d00c`;

/**
 * 서버리스 제한사항 서비스 클래스
 */
export class ServerlessLimitationService {
  private static headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`
  };

  /**
   * 🔐 모드별 제한사항 조회 (서버에서)
   * 
   * @param userMode - 사용자 모드
   * @returns Promise<any>
   */
  static async getModeLimitations(userMode: 'standard' | 'advanced' | 'expert'): Promise<any> {
    try {
      console.log('🔐 서버에서 모드별 제한사항 조회:', { userMode });
      
      const response = await fetch(`${API_BASE_URL}/mode/limitations/${userMode}`, {
        method: 'GET',
        headers: this.headers
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || '모드별 제한사항 조회에 실패했습니다');
      }

      const data = await response.json();
      console.log('✅ 서버에서 모드별 제한사항 조회 완료');
      
      return data;
    } catch (error) {
      console.error('모드별 제한사항 조회 중 오류:', error);
      throw error;
    }
  }

  /**
   * 🔍 실시간 액션 제한 검증 (서버에서)
   * 
   * @param userId - 사용자 ID
   * @param userMode - 사용자 모드
   * @param action - 실행하려는 액션
   * @param currentUsage - 현재 사용량
   * @returns Promise<any>
   */
  static async validateAction(
    userId: string,
    userMode: 'standard' | 'advanced' | 'expert',
    action: string,
    currentUsage: any
  ): Promise<any> {
    try {
      console.log('🔍 서버에서 액션 제한 검증:', { userId, userMode, action });
      
      // Timeout 설정 (10초)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);
      
      const response = await fetch(`${API_BASE_URL}/mode/validate-action`, {
        method: 'POST',
        headers: this.headers,
        signal: controller.signal,
        body: JSON.stringify({
          userId,
          userMode,
          action,
          currentUsage
        })
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        let errorData;
        try {
          errorData = await response.json();
          console.error('🚨 서버리스 액션 검증 실패 상세:', {
            status: response.status,
            statusText: response.statusText,
            errorData,
            requestData: { userId, userMode, action, currentUsage }
          });
        } catch (parseError) {
          console.error('🚨 서버리스 응답 파싱 실패:', parseError);
          errorData = { error: `HTTP ${response.status} ${response.statusText}` };
        }
        throw new Error(errorData.error || '액션 제한 검증에 실패했습니다');
      }

      const data = await response.json();
      console.log('✅ 서버에서 액션 제한 검증 완료:', data.allowed ? '허용' : '제한됨');
      
      return data;
    } catch (error) {
      if (error.name === 'AbortError') {
        console.error('액션 제한 검증 타임아웃');
        throw new Error('서버 응답 시간이 초과되었습니다');
      }
      
      console.error('액션 제한 검증 중 오류:', error);
      throw error;
    }
  }

  /**
   * 📊 사용량 추적 (서버에서)
   * 
   * @param userId - 사용자 ID
   * @param userMode - 사용자 모드
   * @param action - 실행된 액션
   * @param metadata - 추가 메타데이터
   * @returns Promise<any>
   */
  static async trackUsage(
    userId: string,
    userMode: 'standard' | 'advanced' | 'expert',
    action: string,
    metadata?: any
  ): Promise<any> {
    try {
      console.log('📊 서버에서 사용량 추적:', { userId, userMode, action });
      
      const response = await fetch(`${API_BASE_URL}/mode/track-usage`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          userId,
          userMode,
          action,
          metadata
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || '사용량 추적에 실패했습니다');
      }

      const data = await response.json();
      console.log('✅ 서버에서 사용량 추적 완료');
      
      return data;
    } catch (error) {
      console.error('사용량 추적 중 오류:', error);
      throw error;
    }
  }

  /**
   * 📈 현재 사용량 조회 (서버에서)
   * 
   * @param userId - 사용자 ID
   * @returns Promise<any>
   */
  static async getCurrentUsage(userId: string): Promise<any> {
    try {
      console.log('📈 서버에서 현재 사용량 조회:', { userId });
      
      // Timeout 설정 (10초)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);
      
      const response = await fetch(`${API_BASE_URL}/mode/usage/${userId}`, {
        method: 'GET',
        headers: this.headers,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        let errorData;
        try {
          errorData = await response.json();
          console.error('🚨 서버리스 사용량 조회 실패 상세:', {
            status: response.status,
            statusText: response.statusText,
            errorData,
            userId
          });
        } catch (parseError) {
          console.error('🚨 서버리스 응답 파싱 실패:', parseError);
          errorData = { error: `HTTP ${response.status} ${response.statusText}` };
        }
        throw new Error(errorData.error || '현재 사용량 조회에 실패했습니다');
      }

      const data = await response.json();
      console.log('✅ 서버에서 현재 사용량 조회 완료');
      
      return data;
    } catch (error) {
      if (error.name === 'AbortError') {
        console.error('현재 사용량 조회 타임아웃');
        throw new Error('서버 응답 시간이 초과되었습니다');
      }
      
      console.error('현재 사용량 조회 중 오류:', error);
      throw error;
    }
  }

  /**
   * 🚫 클라이언트 폴백 제한사항 (최소한의 기본값)
   * 
   * 서버 연결 실패시 사용하는 기본 제한사항
   * 보안상 가장 제한적인 standard 모드 기준으로 설정
   */
  static getFallbackLimitations() {
    return {
      userMode: 'standard',
      limitations: {
        maxProjects: 2,
        maxConversations: 10,
        maxCustomRoles: 6,
        canExportChats: false,
        canImportChats: false,
        canDuplicateChats: false,
        canCreateCustomRoles: false,
        canAccessAdvancedFeatures: false,
        showAdvancedSettings: false,
        showExpertFeatures: false,
        maxApiCallsPerDay: 50
      },
      features: {
        timelineReminder: false,
        summaryControl: false,
        summaryToggle: false,
        formatSelection: false,
        advancedSettings: false,
        expertFeatures: false,
        customKeywords: false,
        advancedModels: false
      },
      message: '서버 연결 실패로 기본 제한사항을 적용했습니다.'
    };
  }
}

/**
 * 편의 함수들
 */

// 모드별 제한사항 조회 (간편 함수)
export const getModeLimitations = (userMode: 'standard' | 'advanced' | 'expert') => {
  return ServerlessLimitationService.getModeLimitations(userMode);
};

// 액션 제한 검증 (간편 함수)
export const validateAction = (
  userId: string,
  userMode: 'standard' | 'advanced' | 'expert',
  action: string,
  currentUsage: any
) => {
  return ServerlessLimitationService.validateAction(userId, userMode, action, currentUsage);
};

// 사용량 추적 (간편 함수)
export const trackUsage = (
  userId: string,
  userMode: 'standard' | 'advanced' | 'expert',
  action: string,
  metadata?: any
) => {
  return ServerlessLimitationService.trackUsage(userId, userMode, action, metadata);
};

// 현재 사용량 조회 (간편 함수)
export const getCurrentUsage = (userId: string) => {
  return ServerlessLimitationService.getCurrentUsage(userId);
};

/**
 * 액션 타입 정의
 */
export type LimitationAction = 
  | 'create_project'
  | 'create_conversation'
  | 'create_custom_role'
  | 'import_chats'
  | 'duplicate_chats'
  | 'advanced_timeline_settings'
  | 'api_call'
  | 'export_chat';

/**
 * 사용량 타입 정의
 */
export interface CurrentUsage {
  projects: number;
  conversations: number;
  customRoles: number;
  apiCallsToday: number;
  exportedChats: number;
}

/**
 * 제한사항 응답 타입
 */
export interface LimitationResponse {
  success: boolean;
  userMode: string;
  limitations: any;
  features: any;
  timestamp?: string;
}

/**
 * 액션 검증 응답 타입
 */
export interface ActionValidationResponse {
  success: boolean;
  allowed: boolean;
  reason: string;
  upgradeRequired: boolean;
  currentLimits: any;
  currentUsage: CurrentUsage;
}

export default ServerlessLimitationService;
