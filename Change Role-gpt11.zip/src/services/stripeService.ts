/**
 * Stripe 결제 서비스
 * 
 * Stripe 결제, 구독 관리, 상태 조회 기능
 */

import { projectId, publicAnonKey } from '../../utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-e3d1d00c`;

// Stripe 관련 타입 정의
export interface StripeCheckoutSession {
  sessionId: string;
  url: string;
  success: boolean;
}

export interface StripePortalSession {
  url: string;
  success: boolean;
}

export interface SubscriptionStatus {
  hasSubscription: boolean;
  status: 'active' | 'canceled' | 'expired' | 'none';
  subscription?: {
    status: string;
    customerId: string;
    priceId: string;
    currentPeriodStart: string;
    currentPeriodEnd: string;
    isExpired: boolean;
    daysRemaining: number;
  };
  message?: string;
}

/**
 * Stripe 체크아웃 세션 생성
 * @param priceId Stripe Price ID (예: price_1234567890)
 * @param userId 사용자 ID
 * @param email 사용자 이메일 (선택)
 * @returns Promise<StripeCheckoutSession>
 */
export async function createCheckoutSession(
  priceId: string,
  userId: string,
  email?: string
): Promise<StripeCheckoutSession> {
  try {
    console.log('💳 Stripe 체크아웃 세션 생성:', { priceId, userId });
    
    const response = await fetch(`${API_BASE_URL}/stripe/create-checkout-session`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        priceId,
        userId,
        email,
        successUrl: `${window.location.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
        cancelUrl: `${window.location.origin}/cancel`
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || '체크아웃 세션 생성에 실패했습니다');
    }

    const data = await response.json();
    console.log('✅ Stripe 체크아웃 세션 생성 완료');
    
    return data;
  } catch (error) {
    console.error('Stripe 체크아웃 세션 생성 중 오류:', error);
    throw error;
  }
}

/**
 * Stripe 구독 관리 포털 세션 생성
 * @param customerId Stripe Customer ID
 * @returns Promise<StripePortalSession>
 */
export async function createPortalSession(customerId: string): Promise<StripePortalSession> {
  try {
    console.log('🏛️ Stripe 포털 세션 생성:', customerId);
    
    const response = await fetch(`${API_BASE_URL}/stripe/create-portal-session`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        customerId,
        returnUrl: window.location.origin
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || '포털 세션 생성에 실패했습니다');
    }

    const data = await response.json();
    console.log('✅ Stripe 포털 세션 생성 완료');
    
    return data;
  } catch (error) {
    console.error('Stripe 포털 세션 생성 중 오류:', error);
    throw error;
  }
}

/**
 * 사용자 구독 상태 조회
 * @param userId 사용자 ID
 * @returns Promise<SubscriptionStatus>
 */
export async function getSubscriptionStatus(userId: string): Promise<SubscriptionStatus> {
  try {
    console.log('📊 구독 상태 조회:', userId);
    
    const response = await fetch(`${API_BASE_URL}/subscription/${userId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || '구독 상태 조회에 실패했습니다');
    }

    const data = await response.json();
    console.log('✅ 구독 상태 조회 완료:', data.hasSubscription ? '구독 중' : '구독 없음');
    
    return data;
  } catch (error) {
    console.error('구독 상태 조회 중 오류:', error);
    throw error;
  }
}

/**
 * 결제 완료 후 리다이렉트
 * @param priceId Stripe Price ID
 * @param userId 사용자 ID
 * @param email 사용자 이메일 (선택)
 */
export async function redirectToCheckout(
  priceId: string, 
  userId: string, 
  email?: string
): Promise<void> {
  try {
    const session = await createCheckoutSession(priceId, userId, email);
    
    if (session.url) {
      window.location.href = session.url;
    } else {
      throw new Error('체크아웃 URL을 받지 못했습니다');
    }
  } catch (error) {
    console.error('결제 리다이렉트 실패:', error);
    throw error;
  }
}

/**
 * 구독 관리 포털로 리다이렉트
 * @param customerId Stripe Customer ID
 */
export async function redirectToPortal(customerId: string): Promise<void> {
  try {
    const session = await createPortalSession(customerId);
    
    if (session.url) {
      window.location.href = session.url;
    } else {
      throw new Error('포털 URL을 받지 못했습니다');
    }
  } catch (error) {
    console.error('포털 리다이렉트 실패:', error);
    throw error;
  }
}

/**
 * 사용자 ID 생성 또는 가져오기 (Stripe 연동용)
 * @returns string
 */
export function getCurrentUserId(): string {
  let userId = localStorage.getItem('role_gpt_user_id');
  if (!userId) {
    userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('role_gpt_user_id', userId);
  }
  return userId;
}

import { STRIPE_CONFIG } from '../constants/environment';

// Stripe 가격 플랜 정의 (실제 Price ID로 설정)
export const STRIPE_PRICES = {
  STANDARD: STRIPE_CONFIG.prices.standard, // $9.99/월
  ADVANCED: STRIPE_CONFIG.prices.advanced, // $19.99/월  
  EXPERT: STRIPE_CONFIG.prices.expert,     // $39.99/월
} as const;

// 플랜 정보
export const PLANS = {
  STANDARD: {
    name: 'Standard',
    priceId: STRIPE_PRICES.STANDARD,
    price: '$9.99',
    interval: '월',
    features: [
      '최대 2개 프로젝트',
      '10개 대화',
      '6개 커스텀 역할',
      '기본 타임라인 기능',
      '이메일 지원'
    ]
  },
  ADVANCED: {
    name: 'Advanced',
    priceId: STRIPE_PRICES.ADVANCED,
    price: '$19.99',
    interval: '월',
    features: [
      '최대 10개 프로젝트',
      '50개 대화',
      '15개 커스텀 역할',
      '고급 타임라인 & 요약',
      '우선 지원',
      '데이터 내보내기'
    ]
  },
  EXPERT: {
    name: 'Expert',
    priceId: STRIPE_PRICES.EXPERT,
    price: '$39.99',
    interval: '월',
    features: [
      '무제한 프로젝트',
      '무제한 대화',
      '무제한 커스텀 역할',
      '모든 고급 기능',
      '24/7 전용 지원',
      'API 액세스',
      '팀 협업 기능'
    ]
  }
} as const;
