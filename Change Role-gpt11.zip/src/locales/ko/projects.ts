/**
 * 한국어 - 프로젝트 관련 텍스트
 */

export const projects = {
  // 프로젝트 기본
  projects: '프로젝트',
  newProject: '새 프로젝트',
  projectName: '프로젝트 이름',
  projectSettings: '프로젝트 설정',
  
  // 프로젝트 갤러리
  projectGallery: '프로젝트 갤러리',
  projectGalleryTitle: '프로젝트 갤러리',
  projectGallerySubtitle: '관련 채팅들을 프로젝트로 그룹화하여 체계적으로 관리하세요.',
  
  // 프로젝트 액션
  createProject: '프로젝트 생성',
  editProject: '프로젝트 편집',
  deleteProject: '프로젝트 삭제',
  duplicateProject: '프로젝트 복제',
  archiveProject: '프로젝트 보관',
  
  // 프로젝트 상태
  projectEmpty: '비어있는 프로젝트',
  projectWithChats: '{count}개 채팅',
  lastModified: '마지막 수정',
};
