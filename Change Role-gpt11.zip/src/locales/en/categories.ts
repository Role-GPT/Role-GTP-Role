/**
 * English - Category Related Text
 * TODO: Add full English translations
 */

export const categories = {
  categoryAll: 'All',
  categoryLifestyle: 'Lifestyle',
  categoryCreativity: 'Creativity',
  categoryProductivity: 'Productivity',
  categoryLearning: 'Learning & Education',
  categoryProfessional: 'Professional',
  categoryGeneral: 'General',
  categoryMarketing: 'Marketing',
  categorySales: 'Sales',
  
  lifestyle: 'Lifestyle',
  creativity: 'Creativity',
  productivity: 'Productivity',
  education: 'Education',
  professional: 'Professional',
  recommended: 'Recommended',
  popular: 'Popular',
};
