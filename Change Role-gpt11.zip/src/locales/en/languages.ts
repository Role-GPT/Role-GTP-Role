/**
 * English - Language Names
 */

export const languages = {
  english: 'English',
  korean: '한국어',
  japanese: '日本語',
  spanish: 'Español',
  portuguese: 'Português',
  hindi: 'हिन्दी',
};
