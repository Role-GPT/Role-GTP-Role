/**
 * Português - Nomes dos idiomas
 */

export const languages = {
  english: 'Inglês',
  korean: 'Coreano',
  japanese: 'Japonês', 
  spanish: 'Espanhol',
  portuguese: 'Português',
  hindi: 'Hindi',
};
