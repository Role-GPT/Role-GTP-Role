/**
 * हिंदी - भाषाओं के नाम
 */

export const languages = {
  english: 'अंग्रेजी',
  korean: 'कोरियाई',
  japanese: 'जापानी', 
  spanish: 'स्पेनिश',
  portuguese: 'पुर्तगाली',
  hindi: 'हिंदी',
};
