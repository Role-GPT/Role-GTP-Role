/**
 * हिंदी - रोल श्रेणियां
 */

export const categories = {
  // मुख्य श्रेणियां
  business: 'व्यापार',
  creative: 'रचनात्मक', 
  learning: 'शिक्षा',
  lifestyle: 'जीवनशैली',
  technical: 'तकनीकी',
  entertainment: 'मनोरंजन',
  health: 'स्वास्थ्य',
  productivity: 'उत्पादकता',
  
  // उप-श्रेणियां
  marketing: 'मार्केटिंग',
  finance: 'वित्त',
  design: 'डिजाइन',
  writing: 'लेखन',
  education: 'शिक्षा',
  science: 'विज्ञान',
  fitness: 'फिटनेस',
  cooking: 'खाना पकाना',
  programming: 'प्रोग्रामिंग',
  analytics: 'विश्लेषण',
  gaming: 'गेमिंग',
  music: 'संगीत',
};
