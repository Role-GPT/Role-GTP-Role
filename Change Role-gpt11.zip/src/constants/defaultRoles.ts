// 기본 어시스턴트 Role
export const defaultRole = {
  id: 'default',
  name: '어시스턴트',
  description: '도움이 되는 어시스턴트',
  prompt: '당신은 도움이 되는 어시스턴트입니다.',
  category: 'general',
  keywordIds: [],
  temperature: 0.7,
  maxOutputTokens: 2048,
  safetyLevel: 'BLOCK_MEDIUM_AND_ABOVE' as const
};
